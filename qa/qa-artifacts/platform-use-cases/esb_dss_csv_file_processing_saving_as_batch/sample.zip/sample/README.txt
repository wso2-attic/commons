This file contains the details of how to run this sample.

1. Configuring WSO2 DSS (2.6.2)
===============================
    1.1 Setting up the data base
        Create a data base called SHOP_DB and run the orderprocess.sql. This script is given for mysql.
    1.2.Unzip wso2dataservices-2.6.2.zip
    1.3 Copy sample/lib/mysql-connector-java-5.1.14-bin.jar to repository/components/lib/ folder.
    1.4 Edit the sample/conf/OrderService.dbs if required.
    1.5 Create a folder called dataservices under repository/deployment/server
    1.6 Copy sample/conf/OrderService.dbs to repository/deployment/server/dataservices
    1.7 Edit repository/conf/carbon.xml to set offset as 1 (eg. <Offset>1</Offset> )
    1.8 Start the server

2. Configuring WSO2 ESB (4.0.0)
===============================
    1.1 Build the extensions
        Got to sample/extensions and run the maven script to generate the message formatter and builder classes.
        (eg. mvn clean install -Dmaven.test.skip=true -o)
    1.2 Unzip the wso2esb-4.0.0.zip
    1.3 Copy sample/extensions/target/shop-1.0.0.jar to  repository/components/lib/
    1.4 Edit the sample/conf/OrderProcessor.xml ftp file location and DBLookup mediator settins as required.
    1.5 Copy sample/conf/OrderProcessor.xml to repository/deployment/server/synapse-configs/default/proxy-services/ folder
    1.6 Copy sample/conf/orderTransformer.xml to repository/deployment/server/synapse-configs/default/local-entries/
    1.7 Copy sample/conf/axis2.xml to repository/conf/
    1.8 Copy sample/lib/mysql-connector-java-5.1.14-bin.jar to repository/components/lib/ folder
    1.9 Start the server.

