/*
 * Copyright 2004,2005 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package sample.shop.builder;

import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMNamespace;
import org.apache.axiom.soap.SOAPEnvelope;
import org.apache.axiom.soap.SOAPFactory;
import org.apache.axis2.AxisFault;
import org.apache.axis2.builder.Builder;
import org.apache.axis2.context.MessageContext;

import java.io.*;

import sample.shop.formatter.EmailMessageFormatter;

import javax.xml.stream.XMLStreamException;

public class CSVFileBuilder implements Builder {

    public OMElement processDocument(InputStream inputStream,
                                     String s,
                                     MessageContext messageContext) throws AxisFault {

        SOAPFactory soapFactory = OMAbstractFactory.getSOAP11Factory();
        SOAPEnvelope soapEnvelope = soapFactory.getDefaultEnvelope();

        OMNamespace omNamespace = soapFactory.createOMNamespace("http://wso2.org/sample/shop/order", "ns1");

        OMElement batchRequestElement =
                soapFactory.createOMElement("AddOrder_batch_req", omNamespace);

        OMElement addOrderElement = null;

        OMElement orderIDElement = null;
        OMElement customerIDElement = null;
        OMElement dateElement = null;
        OMElement priceElement = null;

        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        try {
            String readLine = bufferedReader.readLine();
            String[] values = null;
            while (readLine != null) {
                addOrderElement = soapFactory.createOMElement("AddOrder", omNamespace);
                values = readLine.split(",");

                //adding child elements.
                orderIDElement = soapFactory.createOMElement("orderID", omNamespace);
                orderIDElement.setText(values[0]);
                addOrderElement.addChild(orderIDElement);

                customerIDElement = soapFactory.createOMElement("customerID", omNamespace);
                customerIDElement.setText(values[1]);
                addOrderElement.addChild(customerIDElement);

                dateElement = soapFactory.createOMElement("date", omNamespace);
                dateElement.setText(values[2]);
                addOrderElement.addChild(dateElement);

                priceElement = soapFactory.createOMElement("price", omNamespace);
                priceElement.setText(values[3]);
                addOrderElement.addChild(priceElement);

                batchRequestElement.addChild(addOrderElement);
                readLine = bufferedReader.readLine();
            }

            soapEnvelope.getBody().addChild(batchRequestElement);
            return soapEnvelope;

        } catch (IOException e) {
            throw new AxisFault("Can not read the input stream", e);
        } finally {
            try {
                bufferedReader.close();
            } catch (IOException e) {
                System.out.println("Error in closing the reader");
            }
        }

    }

    public static void main(String[] args) {
        CSVFileBuilder csvFileBuilder = new CSVFileBuilder();
        try {
            FileInputStream fileInputStream = new FileInputStream("data/orders.txt");
            OMElement omElement =  csvFileBuilder.processDocument(fileInputStream, null, null);
             fileInputStream.close();

            FileOutputStream fileOutputStream = new FileOutputStream("data/orders.xml");
            omElement.serialize(fileOutputStream);
            fileOutputStream.close();

//            MessageContext messageContext = new MessageContext();
//            messageContext.setEnvelope((SOAPEnvelope)omElement);
//
//            EmailMessageFormatter emailMessageFormatter = new EmailMessageFormatter();
//
//            FileOutputStream fileOutputStream = new FileOutputStream("data/results.txt");
//
//            emailMessageFormatter.writeTo(messageContext, null, fileOutputStream, true);
//
//            fileOutputStream.flush();


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (AxisFault axisFault) {
            axisFault.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XMLStreamException e) {
            e.printStackTrace();
        }

    }
}
