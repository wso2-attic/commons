/*
 * Copyright 2004,2005 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package sample.shop.formatter;

import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMOutputFormat;
import org.apache.axiom.soap.SOAPEnvelope;
import org.apache.axis2.AxisFault;
import org.apache.axis2.context.MessageContext;
import org.apache.axis2.transport.MessageFormatter;

import javax.xml.namespace.QName;
import java.io.IOException;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.net.URL;

public class EmailMessageFormatter implements MessageFormatter {

    public byte[] getBytes(MessageContext messageContext,
                           OMOutputFormat omOutputFormat) throws AxisFault {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        writeTo(messageContext, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }

    public void writeTo(MessageContext messageContext,
                        OMOutputFormat omOutputFormat,
                        OutputStream outputStream, boolean b) throws AxisFault {
        writeTo(messageContext, outputStream);

    }

    private void writeTo(MessageContext messageContext, OutputStream outputStream) throws AxisFault {
        SOAPEnvelope soapEnvelope = messageContext.getEnvelope();
        OMElement addOrderElement = soapEnvelope.getBody().getFirstElement();

        String orderID = addOrderElement.getFirstChildWithName(
                new QName("http://wso2.org/sample/shop/order", "orderID")).getText();
        String email = addOrderElement.getFirstChildWithName(
                new QName("http://wso2.org/sample/shop/order", "email")).getText();
        String name = addOrderElement.getFirstChildWithName(
                new QName("http://wso2.org/sample/shop/order", "name")).getText();
        String date = addOrderElement.getFirstChildWithName(
                new QName("http://wso2.org/sample/shop/order", "date")).getText();
        String price = addOrderElement.getFirstChildWithName(
                new QName("http://wso2.org/sample/shop/order", "price")).getText();

        try {
            outputStream.write("Order ID : ".getBytes());
            outputStream.write(orderID.getBytes());
            outputStream.write("\n".getBytes());

            outputStream.write("Email : ".getBytes());
            outputStream.write(email.getBytes());
            outputStream.write("\n".getBytes());

            outputStream.write("Name : ".getBytes());
            outputStream.write(name.getBytes());
            outputStream.write("\n".getBytes());

            outputStream.write("Date : ".getBytes());
            outputStream.write(date.getBytes());
            outputStream.write("\n".getBytes());

            outputStream.write("Price : ".getBytes());
            outputStream.write(price.getBytes());
            outputStream.write("\n".getBytes());


        } catch (IOException e) {
            throw new AxisFault("Can not write to the output stream");
        }

    }

    public String getContentType(MessageContext messageContext,
                                 OMOutputFormat omOutputFormat,
                                 String s) {
        return "text/csv";
    }

    public URL getTargetAddress(MessageContext messageContext,
                                OMOutputFormat omOutputFormat,
                                URL url) throws AxisFault {
        return url;
    }

    public String formatSOAPAction(MessageContext messageContext,
                                   OMOutputFormat omOutputFormat,
                                   String s) {
        return s;
    }
}
