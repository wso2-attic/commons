
CREATE TABLE IF NOT EXISTS ORDER_T (
             ORDER_ID_C VARCHAR (50),
             CUSTOMER_ID_C VARCHAR (50),
             DATAE_C TIMESTAMP,
             PRICE_C DOUBLE,
             PRIMARY KEY (ORDER_ID_C)
)ENGINE INNODB;


CREATE TABLE IF NOT EXISTS CUSTOMER_T (
             CUSTOMER_ID_C VARCHAR (50),
             EMAIL_C VARCHAR (100),
             NAME_C VARCHAR (100),
             PRIMARY KEY (CUSTOMER_ID_C)
)ENGINE INNODB;

insert into CUSTOMER_T values ('001', 'synapse.demo.0@gmail.com','Amila');
insert into CUSTOMER_T values ('003', 'synapse.demo.0@gmail.com','Amila');


