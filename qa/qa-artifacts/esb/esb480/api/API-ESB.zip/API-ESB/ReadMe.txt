ReadMe.txt
------------------

1.) Publish an API from API Manager Publisher.
2.) Subscribe to the API through API Manager Store.
3.) Create API through ESB as described in the synapse artifact.
4.) Invoke the API through the following curl command

curl -v -H "Content-Type: application/xml" -H "Authorization:Bearer a32d1fdaa831e22fdaa0675d84091e5" -X POST -d '<Customer>/<name>joe</name></Customer>' http://localhost:8280/api16/1.0.0
