#!/bin/sh


#
SOURCE_PATH=/home/dushan/poc/server/PT-patch/pack/benchmark-client-wso2
#

# Script to loop test
RUN=$SOURCE_PATH/single_test.sh
# Sample requests directory
REQ_DIR=$SOURCE_PATH/requests
# Depends on the ESB
SERVICE_PREFIX=http://localhost:9000/service/EchoService



# $RUN <iterations> <n> <c> <request.file> <url>

echo "Warm-up..."
$RUN 10 1000 100  $REQ_DIR/1K_buyStocks.xml $SERVICE_PREFIX
echo "Warmup Completed"


echo "500B"
$RUN $ROUNDS 1000 20   $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 1000 40   $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 100  80   $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 100  160  $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 100  320  $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 10   640  $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 10   1280 $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 10   2560 $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX
sleep 10


echo "1K"
$RUN $ROUNDS 1000 20   $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 1000 40   $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 100  80   $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 100  160  $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 100  320  $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 10   640  $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 10   1280 $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 10   2560 $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX
sleep 10


echo "5K"
$RUN $ROUNDS 1000 20   $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 1000 40   $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 100  80   $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 100  160  $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 100  320  $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 10   640  $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 10   1280 $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 10   2560 $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX
sleep 10



echo "10K"
$RUN $ROUNDS 1000 20   $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 1000 40   $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 100  80   $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 100  160  $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 100  320  $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 10   640  $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 10   1280 $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 10   2560 $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX
sleep 10



echo "100K"
$RUN $ROUNDS 1000 20   $REQ_DIR/100K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 1000 40   $REQ_DIR/100K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 100  80   $REQ_DIR/100K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 100  160  $REQ_DIR/100K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 100  320  $REQ_DIR/100K_buyStocks.xml   $SERVICE_PREFIX
sleep 10
$RUN $ROUNDS 10   640  $REQ_DIR/100K_buyStocks.xml   $SERVICE_PREFIX


echo "Test ended"



