java -Xms1024M -Xmx1024M -cp httpcore-4.1.3.jar:httpcore-ab-4.1.3.jar:commons-cli-1.2.jar org.apache.http.benchmark.HttpBenchmark $*
