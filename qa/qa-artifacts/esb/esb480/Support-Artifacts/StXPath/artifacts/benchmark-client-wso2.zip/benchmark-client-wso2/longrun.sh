while [ 1 ]; do
 ./loadtest.sh http://localhost:8280/services >>load_full.txt
done

