#
SOURCE_PATH=/home/wso2/benchmark-client-wso2
#

# Script to loop test
RUN=$SOURCE_PATH/single_test.sh
# Sample requests directory
REQ_DIR=$SOURCE_PATH/requests
# Depends on the ESB 
SERVICE_PREFIX=$1

ROUNDS=1
# $RUN <iterations> <n> <c> <request.file> <url>

echo "Warm-up..."
$RUN 1 10000 20  $REQ_DIR/1K_buyStocks.xml $SERVICE_PREFIX/DirectProxy
$RUN 1 10000 20  $REQ_DIR/1K_buyStocks.xml $SERVICE_PREFIX/CBRProxy
$RUN 1 10000 20  $REQ_DIR/1K_buyStocks.xml $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN 1 10000 20  $REQ_DIR/1K_buyStocks.xml $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN 1 1000 20  $REQ_DIR/1K_buyStocks.xml $SERVICE_PREFIX/XSLTProxy
$RUN 1 1000 20  $REQ_DIR/1K_buyStocks_secure.xml $SERVICE_PREFIX/SecureProxy


echo "Begin performance test..."
echo `date`

#Direct Proxy
echo "Direct 500B"
$RUN $ROUNDS 1000 20   $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 1000 40   $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 100  80   $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 100  160  $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 100  320  $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 100   640  $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 200   1280 $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 200   2560 $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/DirectProxy


echo "Direct 1K"
$RUN $ROUNDS 1000 20   $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 1000 40   $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 100  80   $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 100  160  $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 100  320  $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 100   640  $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 200   1280 $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 200   2560 $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy


echo "Direct 5k"
$RUN $ROUNDS 1000 20   $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 1000 40   $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 100  80   $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 100  160  $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 100  320  $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 100   640  $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 200  1280 $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 200   2560 $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy

echo "Direct 10K"
$RUN $ROUNDS 1000 20   $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 1000 40   $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 100  80   $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 100  160  $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 100  320  $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 100   640  $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
#$RUN $ROUNDS 100   1280 $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
#$RUN $ROUNDS 100   2560 $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy


#echo "Direct 100K"
$RUN $ROUNDS 1000 20   $REQ_DIR/100K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 1000 40   $REQ_DIR/100K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 100  80   $REQ_DIR/100K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 100  160  $REQ_DIR/100K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 100  320  $REQ_DIR/100K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 100  640  $REQ_DIR/100K_buyStocks.xml   $SERVICE_PREFIX/DirectProxy

#-----------------------------------------------------------------------------------------------

#CBR Proxy
echo "CBR 500B"
$RUN $ROUNDS 1000 20   $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 1000 40   $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 100  80   $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 100  160  $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 100  320  $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 100   640  $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 200   1280 $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 200   2560 $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRProxy


echo "CBR 1K"
$RUN $ROUNDS 1000 20   $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 1000 40   $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 100  80   $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 100  160  $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 100  320  $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 100   640  $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 200   1280 $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 200   2560 $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy


echo "CBR 5k"
$RUN $ROUNDS 1000 20   $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 1000 40   $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 100  80   $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 100  160  $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 100  320  $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 100   640  $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 200   1280 $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 200   2560 $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy

echo "CBR 10K"
$RUN $ROUNDS 1000 20   $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 1000 40   $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 100  80   $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 100  160  $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 100  320  $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 100   640  $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 200   1280 $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 200   2560 $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy

echo "CBR 100K"
$RUN $ROUNDS 1000 20   $REQ_DIR/100K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 1000 40   $REQ_DIR/100K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 100  80   $REQ_DIR/100K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 100  160  $REQ_DIR/100K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 100  320  $REQ_DIR/100K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy
$RUN $ROUNDS 10   640  $REQ_DIR/100K_buyStocks.xml   $SERVICE_PREFIX/CBRProxy

#-----i------------------------------------------------------------------------------------------
#CBR SOAP Header Proxy

echo "CBR-SOAP 500B"
$RUN $ROUNDS 1000 20   $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 1000 40   $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 100  80   $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 100  160  $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 100  320  $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 100   640  $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 200   1280 $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 200   2560 $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy

echo "CBR-SOAP 1K"
$RUN $ROUNDS 1000 20   $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 1000 40   $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 100  80   $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 100  160  $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 100  320  $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 100   640  $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 200   1280 $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 200   2560 $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy


echo "CBR-SOAP 5K"
$RUN $ROUNDS 1000 20   $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 1000 40   $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 100  80   $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 100  160  $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 100  320  $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 100   640  $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 200   1280 $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 200   2560 $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy


echo "CBR-SOAP 10K"
$RUN $ROUNDS 1000 20   $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 1000 40   $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 100  80   $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 100  160  $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 100  320  $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 10   640  $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/CBRSOAPHeaderProxy

#-----------------------------------------------------------------------------------------------
#CBR Transport Header Proxy
echo "CBR-Transport 500B"
$RUN $ROUNDS 1000 20   $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 1000 40   $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 100  80   $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 100  160  $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 100  320  $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 100   640  $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 200   1280 $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 200   2560 $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy


echo "CBR-Transport 1K"
$RUN $ROUNDS 1000 20   $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 1000 40   $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 100  80   $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 100  160  $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 100  320  $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 100   640  $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 200   1280 $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 200   2560 $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy


echo "CBR-Transport 5K"
$RUN $ROUNDS 1000 20   $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 1000 40   $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 100  80   $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 100  160  $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 100  320  $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 100   640  $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 200   1280 $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 200   2560 $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy

echo "CBR-Transport 10K"
$RUN $ROUNDS 1000 20   $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 1000 40   $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 100  80   $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 100  160  $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 100  320  $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN $ROUNDS 10   640  $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/CBRTransportHeaderProxy

#-----------------------------------------------------------------------------------------------
#XSLT Proxy
echo "XSLT 500B"
$RUN $ROUNDS 1000 20   $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 1000 40   $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 100  80   $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 100  160  $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 100  320  $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 100   640  $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 200   1280 $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 200   2560 $REQ_DIR/500B_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy

echo "XSLT 1K"
$RUN $ROUNDS 1000 20   $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 1000 40   $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 100  80   $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 100  160  $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 100  320  $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 10   640  $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 200   1280 $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 200   2560 $REQ_DIR/1K_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy

echo "XSLT 5K"
$RUN $ROUNDS 1000 20   $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 1000 40   $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 100  80   $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 100  160  $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 100  320  $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 10   640  $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 200   1280 $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 200   2560 $REQ_DIR/5K_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy


echo "XSLT 10K"
$RUN $ROUNDS 1000 20   $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 1000 40   $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 100  80   $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 100  160  $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 100  320  $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy
$RUN $ROUNDS 10   640  $REQ_DIR/10K_buyStocks.xml   $SERVICE_PREFIX/XSLTProxy




#----------------------------------------------------------------------------------------------------
#Secure Proxy
echo "Secure 500B"
$RUN 1 1000 20   $REQ_DIR/500B_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 1000 40   $REQ_DIR/500B_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 100  80   $REQ_DIR/500B_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 100  160  $REQ_DIR/500B_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 100  320  $REQ_DIR/500B_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 10   640  $REQ_DIR/500B_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 10   1280 $REQ_DIR/500B_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 10   2560 $REQ_DIR/500B_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy

echo "Secure 1K"
$RUN 1 1000 20   $REQ_DIR/1K_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 1000 40   $REQ_DIR/1K_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 100  80   $REQ_DIR/1K_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 100  160  $REQ_DIR/1K_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 100  320  $REQ_DIR/1K_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 10   640  $REQ_DIR/1K_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 10   1280 $REQ_DIR/1K_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 10   2560 $REQ_DIR/1K_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy

echo "Secure 5K"
$RUN 1 1000 20   $REQ_DIR/5K_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 1000 40   $REQ_DIR/5K_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 100  80   $REQ_DIR/5K_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 100  160  $REQ_DIR/5K_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 100  320  $REQ_DIR/5K_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 10   640  $REQ_DIR/5K_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy


echo "Secure 10K"
$RUN 1 1000 20   $REQ_DIR/10K_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 1000 40   $REQ_DIR/10K_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 100  80   $REQ_DIR/10K_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 100  160  $REQ_DIR/10K_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 100  320  $REQ_DIR/10K_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy
$RUN 1 10   640  $REQ_DIR/10K_buyStocks_secure.xml   $SERVICE_PREFIX/SecureProxy

echo "Loadtest Completed"
echo `date`

