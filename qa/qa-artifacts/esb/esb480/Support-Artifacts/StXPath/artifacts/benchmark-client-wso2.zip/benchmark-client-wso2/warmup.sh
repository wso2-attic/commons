#!/bin/sh


#
SOURCE_PATH=/home/wso2/benchmark-client-wso2
#

# Script to loop test
RUN=$SOURCE_PATH/single_test.sh
# Sample requests directory
REQ_DIR=$SOURCE_PATH/requests
# Depends on the ESB
SERVICE_PREFIX=http://localhost:8280/services



# $RUN <iterations> <n> <c> <request.file> <url>

echo "Warm-up..."
$RUN 1 1000 10  $REQ_DIR/10K_buyStocks.xml $SERVICE_PREFIX/DirectProxy
$RUN 1 1000 10  $REQ_DIR/10K_buyStocks.xml $SERVICE_PREFIX/CBRProxy
$RUN 1 1000 10  $REQ_DIR/10K_buyStocks.xml $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN 1 1000 10  $REQ_DIR/10K_buyStocks.xml $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN 1 1000 10  $REQ_DIR/10K_buyStocks.xml $SERVICE_PREFIX/XSLTProxy
$RUN 1 1000 10  $REQ_DIR/10K_buyStocks.xml $SERVICE_PREFIX/XSLTEnhancedProxy
$RUN 1 1000 10  $REQ_DIR/1K_buyStocks_secure.xml $SERVICE_PREFIX/SecureProxy



echo "Warmup Completed"


