#
SOURCE_PATH=/home/dushan/poc/server/PT-patch/pack/benchmark-client-wso2
#

# Script to loop test
RUN=$SOURCE_PATH/single_test.sh
# Sample requests directory
REQ_DIR=$SOURCE_PATH/requests
# Depends on the ESB 
SERVICE_PREFIX=$1

ROUNDS=1

# $RUN <iterations> <n> <c> <request.file> <url>

echo "Warm-up..."
$RUN $ROUNDS 100 20  $REQ_DIR/1K_buyStocks.xml $SERVICE_PREFIX/DirectProxy
$RUN $ROUNDS 100 20  $REQ_DIR/1K_buyStocks.xml $SERVICE_PREFIX/CBRProxy
$RUN 1 100 20 $REQ_DIR/1K_buyStocks.xml $SERVICE_PREFIX/CBRSOAPHeaderProxy
$RUN $ROUNDS 100 20  $REQ_DIR/1K_buyStocks.xml $SERVICE_PREFIX/CBRTransportHeaderProxy
$RUN 1  1000 20    $REQ_DIR/1K_buyStocks.xml $SERVICE_PREFIX/XSLTProxy
$RUN  1 1000 20   $REQ_DIR/1K_buyStocks.xml $SERVICE_PREFIX/XSLTEnhancedProxy
$RUN $ROUNDS 100 20  $REQ_DIR/1K_buyStocks_secure.xml $SERVICE_PREFIX/SecureProxy


echo "Loadtest Completed"
echo `date`

