package com.springsource.pizzashop.service;


public class PizzaServiceImpl implements PizzaService {
}
