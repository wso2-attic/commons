package com.springsource.pizzashop.service;


public class PizzaOrderServiceImpl implements PizzaOrderService {
}
