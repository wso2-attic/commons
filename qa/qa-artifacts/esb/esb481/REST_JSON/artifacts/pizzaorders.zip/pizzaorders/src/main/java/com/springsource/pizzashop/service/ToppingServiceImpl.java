package com.springsource.pizzashop.service;


public class ToppingServiceImpl implements ToppingService {
}
