package com.springsource.pizzashop.service;


public class BaseServiceImpl implements BaseService {
}
