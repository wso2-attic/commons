package com.springsource.pizzashop.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Topping.class)
public class ToppingDataOnDemand {
}
