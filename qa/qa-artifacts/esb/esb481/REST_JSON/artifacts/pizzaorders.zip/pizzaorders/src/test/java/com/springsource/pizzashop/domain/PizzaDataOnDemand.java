package com.springsource.pizzashop.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Pizza.class)
public class PizzaDataOnDemand {
}
