package com.springsource.pizzashop.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Base.class)
public class BaseDataOnDemand {
}
