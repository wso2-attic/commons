package com.springsource.pizzashop.service;

import org.springframework.roo.addon.layers.service.RooService;

@RooService(domainTypes = { com.springsource.pizzashop.domain.PizzaOrder.class })
public interface PizzaOrderService {
}
