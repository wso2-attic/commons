package com.springsource.pizzashop.domain;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Pizza.class)
public class PizzaIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
