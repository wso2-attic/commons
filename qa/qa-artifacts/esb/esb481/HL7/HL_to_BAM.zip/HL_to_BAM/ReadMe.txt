Scenario: The 3 proxies use different ways to publish message to the wso2BAM

Precondition
1.the patch patch0143/ should be applied prior to running this example
2.hl7 HL7TransportListener,HL7TransportSender, HL7MessageFormatter and HL7MessageBuilder should be enabled within the axis2.xml


Copy to proxy-services
HL7ToBAM.xml
HL7ToBAMTB.xml
HL7ToBAM_MESSTRACE.xml

Scenario 1:Publish messages via BAM Server profile
--------------------------------------------------

steps
1.create a BAM server profile within the ESB
2.create a BAM mediator within the proxy HL7ToBAM.xml to call to the BAM server profile
3.give a port that will listen to incomming BAM messages    <parameter name="transport.hl7.Port">55555</parameter>
4.send a message via the HAPI client
5.login to BAM and run the cassendra explorer

Scenario 2:Publish message via ESB to a hl7 toolbox
--------------------------------------------------
steps
1.install the hl7.tbx within BAM. we use WSO2-BAM.2.4.0
2.deploy the proxy HL7ToBAMTB.xml within the ESB
3.send a message from HAPI client to the proxy service listing on the port defigned at    <parameter name="transport.hl7.Port">55555</parameter>
4.login to BAM and run the cassendra explorer
5.login to BAM and login to the activity dashboard and filter the results

Note:https://support.wso2.com/jira/browse/CSIPEMDEVSPRT-160

Scenario 3: Publish messages via BAM Message_Tracer
----------------------------------------------------

steps
1.install the feature BAM Message Tracer Hanlder Aggrigator. follow http://www.yenlo.nl/nl/setting-up-message-tracing-for-wso2-esb-4-8-0-with-wso2-bam-2-4-0/
2.access the BAM message tracer within the ESB under configurations and set the parameters
3.deploy the proxy HL7ToBAM_MESSTRACE.xml
4.configure a port that can listen to incomming HL7 messages within the proxy    <parameter name="transport.hl7.Port">55555</parameter>
5.send a message via the HAPI client
6.login to BAM and access the cassendra explorer and check under EVENT_KS Access the  BAM_MESSAGE_TRACE to see the published messages
