Scenario: this scenario uses the vfs transport and not the hl7 transport. The objective is to transfer files with hl7 messages

Precondition
------------
1.vfs TransportListener and TransportSender should be enabled within the axis2.xml

Copy to proxy-services
----------------------
FileSystemToFileSystem.xml

Steps
1.create two folders within the file system as "in" and "out" within /tmp as /tmp/in and /tmp/out
2.update the paths as given within the proxy-service
3.create a file with the hl7 extension as largemessage.hl7 and add a hl7 message
4.copy the message to the path /tmp/in 
Note: if the ESB is up the file should be transfered to the /tmp/out folder 
