Scenario: This looks at validating incomming messages against a schema and accepting only those messages that match the schema

Preconditions
-------------
1.hl7 HL7TransportListener,HL7TransportSender, HL7MessageFormatter and HL7MessageBuilder should be enabled within the axis2.xml

Copy to proxy-services
----------------------
CustomProxy.xml

steps
1.place the ADT_A31.xml custom schema in any folder location
2.give the path to the proxy within the property    <parameter name="transport.hl7.ConformanceProfilePath"> ex:   <parameter name="transport.hl7.ConformanceProfilePath">file:///home/shavantha/Downloads/ADT_A31.xml</parameter>
3.From HAPI Client send the message MSH|^~\&|A|B|C|3910|||ADT^A31^ADT_A05|1001|T|2.4

Note: if the message sent is MSH|^~\&|A|B|C|3910|||ADT^A31^ADT_A05|1001|T|2.4 the custom schema should pass the validated message if any other message is sent an error should be thrown 
