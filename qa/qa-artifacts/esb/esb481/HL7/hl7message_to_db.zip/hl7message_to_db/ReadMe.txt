Scenarion: the looks at saving hl7 messages received to a mysql database. The saved messages can be checked from the hl7 console

Precondition
1.hl7 HL7TransportListener,HL7TransportSender, HL7MessageFormatter and HL7MessageBuilder should be enabled within the axis2.xml

Copy to the folder proxy-services
------------------------------------
HL7Store.xml

Copy to Sequence Folder
----------------------
SendSequence.xml
StoreInJDBCSequence.xml

Copy to message-store
------------------------
HL7StoreJPA.xml

Create a database called hl7storejpa
Give the connection details to the database within the message store
From the HAPI Client send a message to the port in which the proxy is listing   <parameter name="transport.hl7.Port">55555</parameter>
Check the database

