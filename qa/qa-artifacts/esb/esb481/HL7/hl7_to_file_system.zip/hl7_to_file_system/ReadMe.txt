Scenario: This scenario will listen to incomming HL7 messages and save them within the folder location given as an xml message

Precondition
1.hl7 HL7TransportListener,HL7TransportSender, HL7MessageFormatter and HL7MessageBuilder should be enabled within the axis2.xml

Copy to proxy services
----------------------
HL7ToFileSystem2.xml

Create a folder within the path /tmp called "in" ex: /tmp/in
Send a message from the HAPIClient   <parameter name="transport.hl7.Port">55555</parameter>
Check the file system path
