function search(searchUrl) {
	var scraper = new Scraper(
		<config>
				<var-def name="url">{searchUrl}</var-def>
				<var-def name="response">
					<xpath expression="//div[@id='bodyContent']//ul[@class='resultsList']/li/a">
						<html-to-xml>
						   <http method='get' url='${url}'/>
						</html-to-xml>
					</xpath>
				</var-def>
		</config>

	);
	print(scraper.response);
	return new XMLList(scraper.response);
}
