// Echo xs:byte
echoXSbyte.inputTypes="xs:byte";
echoXSbyte.outputType="xs:byte";
function echoXSbyte(param) {
    return param;
}

// Echo xs:nonNegativeInteger
echoXSnonNegativeInteger.inputTypes="xs:nonNegativeInteger";
echoXSnonNegativeInteger.outputType="xs:nonNegativeInteger";
function echoXSnonNegativeInteger(param) {
    return param;
}

// Echo xs:unsignedLong
echoXSunsignedLong.inputTypes="xs:unsignedLong";
echoXSunsignedLong.outputType="xs:unsignedLong";
function echoXSunsignedLong(param) {
    return param;
}

// Echo xs:unsignedInt
echoXSunsignedInt.inputTypes="xs:unsignedInt";
echoXSunsignedInt.outputType="xs:unsignedInt";
function echoXSunsignedInt(param) {
    return param;
}

// Echo xs:unsignedShort
echoXSunsignedShort.inputTypes="xs:unsignedShort";
echoXSunsignedShort.outputType="xs:unsignedShort";
function echoXSunsignedShort(param) {
    return param;
}

// Echo xs:unsignedByte
echoXSunsignedByte.inputTypes="xs:unsignedByte";
echoXSunsignedByte.outputType="xs:unsignedByte";
function echoXSunsignedByte(param) {
    return param;
}

// Echo xs:positiveInteger
echoXSpositiveInteger.inputTypes="xs:positiveInteger";
echoXSpositiveInteger.outputType="xs:positiveInteger";
function echoXSpositiveInteger(param) {
    return param;
}

// Echo xs:decimal
echoXSdecimal.inputTypes="xs:decimal";
echoXSdecimal.outputType="xs:decimal";
function echoXSdecimal(param) {
    return param;
}

// Echo xs:boolean
echoXSboolean.inputTypes="xs:boolean";
echoXSboolean.outputType="xs:boolean";
function echoXSboolean(param) {
    return param;
}

// Echo xs:dateTime
echoXSdateTime.inputTypes="xs:dateTime";
echoXSdateTime.outputType="xs:dateTime";
function echoXSdateTime(param) {
    return param;
}

// Echo xs:date
echoXSdate.inputTypes="xs:date";
echoXSdate.outputType="xs:date";
function echoXSdate(param) {
    return param;
}

// Echo xs:time
echoXStime.inputTypes="xs:time";
echoXStime.outputType="xs:time";
function echoXStime(param) {
    return param;
}

// Echo xs:gYearMonth
echoXSgYearMonth.inputTypes="xs:gYearMonth";
echoXSgYearMonth.outputType="xs:gYearMonth";
function echoXSgYearMonth(param) {
    return param;
}

// Echo xs:gMonthDay
echoXSgMonthDay.inputTypes="xs:gMonthDay";
echoXSgMonthDay.outputType="xs:gMonthDay";
function echoXSgMonthDay(param) {
    return param;
}

// Echo xs:gYear
echoXSgYear.inputTypes="xs:gYear";
echoXSgYear.outputType="xs:gYear";
function echoXSgYear(param) {
    return param;
}

// Echo xs:gDay
echoXSgDay.inputTypes="xs:gDay";
echoXSgDay.outputType="xs:gDay";
function echoXSgDay(param) {
    return param;
}

// Echo xs:gMonth
echoXSgMonth.inputTypes="xs:gMonth";
echoXSgMonth.outputType="xs:gMonth";
function echoXSgMonth(param) {
    return param;
}

// Echo xs:anyType
echoXSanyType.inputTypes="xs:anyType";
echoXSanyType.outputType="xs:anyType";
function echoXSanyType(param) {
    return param;
}

// Echo xs:QName
echoXSQName.inputTypes="xs:QName";
echoXSQName.outputType="xs:QName";
function echoXSQName(param) {
    return param;
}

// Echo xs:hexBinary
echoXShexBinary.inputTypes="xs:hexBinary";
echoXShexBinary.outputType="xs:hexBinary";
function echoXShexBinary(param) {
    return param;
}

// Echo xs:base64Binary
echoXSbase64Binary.inputTypes="xs:base64Binary";
echoXSbase64Binary.outputType="xs:base64Binary";
function echoXSbase64Binary(param) {
    return param;
}