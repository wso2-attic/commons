this.scope = "application";
this.init = startupFunc;

startupFunc.visible = false;

//prints the message "Startup Task Triggered" in every 2 seconds as soon as mashup get deployed
function startupFunc() {
	system.setInterval(log, 2000, ["Startup Task Triggered"], null, null, "startupTask");
}

//prints the message "setIntervalCodeTest Triggered" in every 2 seconds as soon as this operation get called
setIntervalCodeTest.inputTypes = {"setIntervalCodeTest" : "string"};
function setIntervalCodeTest(setIntervalCodeTest) {
	system.setInterval("log('setIntervalCodeTest Triggered');", 2000, setIntervalCodeTest);
}

//prints the message "setIntervalArgsTest Triggered" in every 2 seconds as soon as this operation get called
setIntervalArgsTest.inputTypes = {"setIntervalArgsTest" : "string"};
function setIntervalArgsTest(setIntervalArgsTest) {
	system.setInterval(log, 2000, ["setIntervalArgsTest Triggered"], setIntervalArgsTest);
}

//prints the message "setIntervalStartTimeTest Triggered" in every 2 seconds. This begins at (the time operation get called + 20 seconds)
setIntervalStartTimeTest.inputTypes = {"setIntervalStartTimeTest" : "string"};
function setIntervalStartTimeTest(setIntervalStartTimeTest) {
	var startTime = new Date();
	startTime.setSeconds(startTime.getSeconds + 20);
	system.setInterval(log, 2000, ["setIntervalStartTimeTest Triggered"], startTime, setIntervalStartTimeTest);
}

//prints the message "setIntervalEndTimeTest Triggered" in every 2 seconds. This begins as soon as this operation get called
//and ends at (the time operation get called + 20 seconds)
setIntervalEndTimeTest.inputTypes = {"setIntervalEndTimeTest" : "string"};
function setIntervalEndTimeTest(setIntervalEndTimeTest) {
	var endTime = new Date();
  print(endTime.toString());
	endTime.setSeconds(endTime.getSeconds + 20);
	system.setInterval(log, 1000, ["setIntervalEndTimeTest Triggered"], null, endTime, setIntervalEndTimeTest);
}

//prints the message "setIntervalEndTimeTest Triggered" in every 2 seconds. This begins at (the time operation get called + 20 seconds)
//and ends at (the time operation get called + 20 seconds)
setIntervalStartEndTimesTest.inputTypes = {"setIntervalStartEndTimesTest" : "string"};
function setIntervalStartEndTimesTest(setIntervalStartEndTimesTest) {
	var startTime = new Date();
	var endTime = new Date();
  print(startTime.toString());
  print(endTime.toString());
	startTime.setSeconds(startTime.getSeconds + 20);
	endTime.setSeconds(endTime.getSeconds + 40);
	system.setInterval(log, 1000, ["setIntervalStartEndTimesTest Triggered"], startTime, endTime, setIntervalStartEndTimesTest);
}

//prints the message "setIntervalUUIDTest Triggered" in every 2 seconds
//setIntervalUUIDTest.inputTypes = {"setIntervalUUIDTest" : "xs:string"};
function setIntervalUUIDTest() {
        session.put("taskUUIDTest", system.setInterval(log, 2000, ["setIntervalUUIDTest Triggered"]));
}

//prints true or false if the availability of the "startupTask"
function isTaskActiveTest() {
	log(system.isTaskActive("startupTask")); 
}

//clear all the setInterval tasks created here
function clearIntervalTest() {
	if(system.isTaskActive("startupTask")) {
		system.clearInterval("startupTask");
	}
	if(system.isTaskActive("setIntervalCodeTest")) {
		system.clearInterval("setIntervalCodeTest");
	}
	if(system.isTaskActive("setIntervalArgsTest")) {
		system.clearInterval("setIntervalArgsTest");
	}
	if(system.isTaskActive("setIntervalStartTimeTest")) {
		system.clearInterval("setIntervalStartTimeTest");
	}
	if(system.isTaskActive("setIntervalEndTimeTest")) {
		system.clearInterval("setIntervalEndTimeTest");
	}
	if(system.isTaskActive("setIntervalStartEndTimesTest")) {
		system.clearInterval("setIntervalStartEndTimesTest");
	}

	var uuid = session.get("taskUUIDTest");
	if(uuid != null) {
		if(system.isTaskActive(uuid)) {
			system.clearInterval(uuid);
		}
	}	
}

//prints the message "setTimeoutTest Triggered" after 10 seconds
setTimeoutTest.inputTypes = {"setTimeoutTest" : "string"};
function setTimeoutTest(setTimeoutTest) {
	system.setTimeout("log('setTimeoutTest Triggered');", 20000, setTimeoutTest);
}

//this creates a setTimeout task and clear it at the same time, so no task should be executed nor printed
function clearTimeoutTest() {
	var taskName = system.setTimeout("log('clearTimout ERROR');", 20000, clearTimeoutTest);
	system.clearTimeout(taskName);
	log(taskName + "  cleared");
}

log.visible = false;
function log(message) {
var text = message + " " + new Date().toString();
var file = new File("taskLog.txt");
if (!file.exists)
file.createFile();
file.openForAppending();
file.writeLine(text)
}




                
