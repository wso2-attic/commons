// Echo xs:string
echoXSstring.inputTypes="xs:string";
echoXSstring.outputType="xs:string";
function echoXSstring(param) {
    return param;
}

// Echo xs:normalizedString
echoXSnormalizedString.inputTypes="xs:normalizedString";
echoXSnormalizedString.outputType="xs:normalizedString";
function echoXSnormalizedString(param) {
    return param;
}

// Echo xs:token
echoXStoken.inputTypes="xs:token";
echoXStoken.outputType="xs:token";
function echoXStoken(param) {
    return param;
}

// Echo xs:language
echoXSlanguage.inputTypes="xs:language";
echoXSlanguage.outputType="xs:language";
function echoXSlanguage(param) {
    return param;
}

// Echo xs:Name
echoXSName.inputTypes="xs:Name";
echoXSName.outputType="xs:Name";
function echoXSName(param) {
    return param;
}

// Echo xs:NCName
echoXSNCName.inputTypes="xs:NCName";
echoXSNCName.outputType="xs:NCName";
function echoXSNCName(param) {
    return param;
}

// Echo xs:NOTATION
echoXSNOTATION.inputTypes="xs:NOTATION";
echoXSNOTATION.outputType="xs:NOTATION";
function echoXSNOTATION(param) {
    return param;
}

// Echo xs:anyURI
echoXSanyURI.inputTypes="xs:anyURI";
echoXSanyURI.outputType="xs:anyURI";
function echoXSanyURI(param) {
    return param;
}

// Echo xs:float
echoXSfloat.inputTypes="xs:float";
echoXSfloat.outputType="xs:float";
function echoXSfloat(param) {
    return param;
}

// Echo xs:double
echoXSdouble.inputTypes="xs:double";
echoXSdouble.outputType="xs:double";
function echoXSdouble(param) {
    return param;
}

// Echo xs:duration
echoXSduration.inputTypes="xs:duration";
echoXSduration.outputType="xs:duration";
function echoXSduration(param) {
    return param;
}

// Echo xs:integer
echoXSinteger.inputTypes="xs:integer";
echoXSinteger.outputType="xs:integer";
function echoXSinteger(param) {
    return param;
}

// Echo xs:nonPositiveInteger
echoXSnonPositiveInteger.inputTypes="xs:nonPositiveInteger";
echoXSnonPositiveInteger.outputType="xs:nonPositiveInteger";
function echoXSnonPositiveInteger(param) {
    return param;
}

// Echo xs:negativeInteger
echoXSnegativeInteger.inputTypes="xs:negativeInteger";
echoXSnegativeInteger.outputType="xs:negativeInteger";
function echoXSnegativeInteger(param) {
    return param;
}

// Echo xs:long
echoXSlong.inputTypes="xs:long";
echoXSlong.outputType="xs:long";
function echoXSlong(param) {
    return param;
}

// Echo xs:int
echoXSint.inputTypes="xs:int";
echoXSint.outputType="xs:int";
function echoXSint(param) {
    return param;
}

// Echo xs:short
echoXSshort.inputTypes="xs:short";
echoXSshort.outputType="xs:short";
function echoXSshort(param) {
    return param;
}

