function searchGoogle(query) {
	var client = new HttpClient();
	var content = [ 
		{ name : "q", value : query }, 
		{ name : "btnG", value : "Google Search" }, 
		{ name : "hl", value : "en" }, 
		{ name : "source", value : "hp" } 
	];
	var params = {	
		followRedirect : true
	};

	var code = client.executeMethod("GET", "http://google.com/search", content, params);
	if(code == 200) {
		return "<success>" + client.response + "</success>";
	} else {
		return "<failure><code>" + code + "</code><statusText>" + client.statusText + "</statusText></failure>";
	}
}