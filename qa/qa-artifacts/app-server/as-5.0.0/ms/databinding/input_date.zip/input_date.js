testDate.inputTypes = "date";
testDate.outputType = "date";
function testDate(param) {
    return param;
}
