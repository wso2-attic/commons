testBoolean.inputTypes = "Boolean";
testBoolean.outputType = "Boolean";
function testBoolean(param) {
      return param;
 }
