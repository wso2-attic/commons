testNumber.inputTypes = "number";
testNumber.outputType = "number";
function testNumber(param) {
    return param;
 }
