getVersion.inputTypes = { "first" : "string" }; getVersion.outputType = "anyType";
function getVersion() {
return first;}
