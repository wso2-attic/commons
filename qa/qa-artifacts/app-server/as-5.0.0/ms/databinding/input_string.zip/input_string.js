testString.inputTypes = "string";
testString.outputType = "string";
function testString(param) {
     return param;
}
