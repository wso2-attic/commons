NoInput.inputTypes = "";
NoInput.outputType = "string";
function NoInput() {
 return "test"}
