                this.serviceName = "ApplicationScopeService";
                this.scope="application";
                
                var key = "number";

                function putValue(param) {
                    session.put(key,2);
                    return <success/>;
                }

                function getValue(param) {
                    var number = session.get(key);
                    return <number>{number}</number>;
                }

                function removeValue(param) {
                    session.remove(key);
                    return <success/>;
                }

                function clearSession(param) {
                    session.clear();
                    return <success/>;
                }
