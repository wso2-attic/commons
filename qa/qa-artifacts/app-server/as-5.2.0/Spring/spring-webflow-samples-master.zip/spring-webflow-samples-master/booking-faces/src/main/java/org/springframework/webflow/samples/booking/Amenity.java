package org.springframework.webflow.samples.booking;

public enum Amenity {
    OCEAN_VIEW, LATE_CHECKOUT, MINIBAR;
}
