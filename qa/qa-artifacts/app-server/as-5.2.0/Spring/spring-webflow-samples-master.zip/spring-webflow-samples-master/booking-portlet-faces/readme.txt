
Starting with version 2.2, Spring Web Flow provides support for JSF Portlets using its own internal 
Portlet integration rather than a Portlet Bridge for JSF. 

This sample demonstrates that support. It has been tested on Apache Pluto 2.0.1 with Portlet 
API 2.0 and JSF 1.2 (both Mojarra and MyFaces).

See the reference documentation for more information.
