
This sample uses Thymeleaf and Tiles for the view templating technology. To trace the steps of converting a JSP/Tiles application to Thymeleaf, refer to the description and the commits of [the pull request](https://github.com/SpringSource/spring-webflow-samples/pull/5) that introduced the change. For more details on Thymeleaf refer to [http://www.thymeleaf.org/](http://www.thymeleaf.org/).
