CoffeeShopClient = new function() {
	
this.addOrder = function() {
var orderName = $('#orderName').val();
CoffeShopAppUtil.makeRequest("POST","/coffeeshop/orders/order.jag?", "order="+orderName, function(html) {	});
console.log("Call add Order "+orderName);
}

this.viewOrder = function() {
var orderid = $('#orderid').val();
CoffeShopAppUtil.makeRequest("GET","/coffeeshop/orders/"+orderid+"/", null , function(html) {	});
console.log("view order "+orderid);
}

this.viewOrders = function() {
CoffeShopAppUtil.makeRequest("GET","/coffeeshop/orders/", null , function(html) {	});
console.log("view orders ");
}

this.addAddittion = function() {
var addition = $('#addition').val();
var orderid = $('#orderid').val();
var content = '{"addition":'+addition+'}';
CoffeShopAppUtil.makeRequest("PUT","/coffeeshop/orders/"+orderid, content , function(html) {	});
console.log("Call add additon "+ addition + " on "+orderid);
}

this.updateStatus = function() {
var status = $('#status').val();
var orderid = $('#orderid').val();
var content = '{"status":'+status+'}';
CoffeShopAppUtil.makeRequest("PUT","/coffeeshop/orders/"+orderid, content , function(html) {	});
console.log("Call add status "+ status + " on "+orderid);
}

this.isPaidOrder = function() {
var orderid = $('#orderid').val();
CoffeShopAppUtil.makeRequest("GET","/coffeeshop/payments/"+orderid, null , function(html) {	});
console.log("Check order is paid "+orderid);
}

this.payOrder = function() {
var orderid = $('#orderid').val();
CoffeShopAppUtil.makeRequest("PUT","/coffeeshop/payments/"+orderid, null , function(html) {	});
console.log("Call for pay order "+orderid);
}

this.deletOrder = function() {
var orderid = $('#orderid').val();
CoffeShopAppUtil.makeRequest("DELETE","/coffeeshop/orders/"+orderid+"/", null , function(html) {	});
console.log("Call for delet order "+orderid);
}

this.runAll = function() {
var orderName = "Percolator";
var orderid =1;
var status = "Completed";
var addition = "Peppermint";

//POST Testing
CoffeShopAppUtil.makeRequest("POST","/coffeeshop/orders/order.jag?", "order="+orderName, function(html) {	});
console.log("Call add Order "+orderName);

//adding adition (PUT)
var content = '{"addition":'+addition+'}';
CoffeShopAppUtil.makeRequest("PUT","/coffeeshop/orders/"+orderid, content , function(html) {	});
console.log("Call add additon "+ addition + " on "+orderid);

//updating status (PUT with contant)
var content = '{"status":'+status+'}';
CoffeShopAppUtil.makeRequest("PUT","/coffeeshop/orders/"+orderid, content , function(html) {	});
console.log("Call add status "+ status + " on "+orderid);

//paying (PUT on non contant)
CoffeShopAppUtil.makeRequest("PUT","/coffeeshop/payments/"+orderid, null , function(html) {	});
console.log("Call for pay order "+orderid);

//checking pay (GET test)
CoffeShopAppUtil.makeRequest("GET","/coffeeshop/payments/"+orderid, null , function(html) {	});
console.log("Check order is paid "+orderid);

//detetin order (DEELTE)
CoffeShopAppUtil.makeRequest("DELETE","/coffeeshop/orders/"+orderid+"/", null , function(html) {	});
console.log("Call for delet order "+orderid);

}
}