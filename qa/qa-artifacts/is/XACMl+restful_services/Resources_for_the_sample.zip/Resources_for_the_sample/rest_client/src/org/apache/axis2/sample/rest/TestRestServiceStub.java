/*
 * Copyright 2004,2005 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.axis2.sample.rest;

import org.apache.axiom.om.impl.builder.StAXOMBuilder;
import org.apache.axis2.AxisFault;
import org.apache.axis2.client.ServiceClient;
import org.apache.axis2.context.ConfigurationContext;
import org.apache.axis2.context.ConfigurationContextFactory;
import org.apache.axis2.sample.rest.types.Student;
import org.apache.axis2.sample.rest.types.StudentName;
import org.apache.axis2.client.Options;
import org.apache.axis2.Constants;
import org.apache.axis2.transport.http.HTTPConstants;
import org.apache.axis2.transport.http.HttpTransportProperties;
import org.apache.neethi.Policy;
import org.apache.neethi.PolicyEngine;
import org.apache.rampart.RampartMessageData;

import javax.xml.stream.XMLStreamException;
import java.io.File;
import java.io.FileNotFoundException;

public class TestRestServiceStub {
    private static String KEY_STORE_DIR = "/home/hasini/WSO2/wso2esb-4.0.0/repository/resources/security/wso2carbon.jks";

    public static void main(String[] args) {
        try {

            //security related initializations
            System.setProperty("javax.net.ssl.trustStore", KEY_STORE_DIR);
            System.setProperty("javax.net.ssl.trustStorePassword", "wso2carbon");

            RestServiceStub stub = new RestServiceStub("https://localhost:8243/services/xacml_rest_proxy");

            //login as admin
            HttpTransportProperties.Authenticator authenticator = new HttpTransportProperties.Authenticator();
            authenticator.setUsername("admin");
            authenticator.setPassword("admin");
            //enable REST when invoking the service
            stub._getServiceClient().getOptions().setProperty(HTTPConstants.AUTHENTICATE, authenticator);
            stub._getServiceClient().getOptions().setProperty(Constants.Configuration.ENABLE_REST, Constants.VALUE_TRUE);

            //create student by admin
            System.out.println("Creating student by admin...");
            Student student = new Student();
            student.setName("Will");
            student.setAge(32);
            student.setSubjects(new String[]{"maths", "science"});
            stub.add(student);

            stub._getServiceClient().cleanupTransport();

            //login as non admin user.
            authenticator.setUsername("hasini");
            authenticator.setPassword("hasini");

            stub._getServiceClient().getOptions().setProperty(HTTPConstants.AUTHENTICATE, authenticator);
            stub._getServiceClient().getOptions().setProperty(Constants.Configuration.ENABLE_REST, Constants.VALUE_TRUE);

            //get student by non admin user
            System.out.println("Getting student by non admin user..");
            StudentName studentName = new StudentName();
            studentName.setName("Will");
            Student result = stub.get(studentName);
            System.out.println("Student's age="+result.getAge()+" successfully read by non admin user..");

            //update student by non admin user
            System.out.println("Updating student by non admin user..");
            result.setAge(40);
            result.setSubjects(new String[]{"english", "history"});
            stub.update(result);
            
        } catch (AxisFault axisFault) {
            System.out.println("Operation failed..");
            axisFault.printStackTrace();
        } catch (java.rmi.RemoteException e) {
            System.out.println("Operation failed..");
            e.printStackTrace();
        }
    }
    
}
