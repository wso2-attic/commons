package org.wso2.entitlement.sample;

import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMFactory;
import org.apache.axiom.om.OMNamespace;
import org.apache.axiom.om.impl.builder.StAXOMBuilder;
import org.apache.axis2.Constants;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.Options;
import org.apache.axis2.client.ServiceClient;
import org.apache.axis2.context.ConfigurationContext;
import org.apache.axis2.context.ConfigurationContextFactory;
import org.apache.neethi.Policy;
import org.apache.neethi.PolicyEngine;
import org.apache.rampart.RampartMessageData;

public class WSEntitlementTestClient {
	 
	 final static String ADDR_URL = "http://localhost:8280/services/echo"; //"http://localhost:8280/services/MarketDataService";
	 final static String TRANS_URL =  "https://localhost:8243/services/EntitlementService"; // "https://localhost:8243/services/EntitlementProxy";
	 
	 public static void main(String[] args) throws Exception {
	  ServiceClient client = null;
	  Options options = null;
	  OMElement response = null;
	  ConfigurationContext context = null;
	  String trustStore = null;

	  // You need to import the ESBs public certificate to this key store.
	  trustStore = "wso2carbon.jks";
	  // We are accessing ESB over HTTPS - so need to set trustStore parameters.
	  System.setProperty("javax.net.ssl.trustStore", trustStore);
	  // Password of mykeystore.jks
	  System.setProperty("javax.net.ssl.trustStorePassword", "wso2carbon");

	  // Create configuration context - you will have Rampart module engaged in the client.axis2.xml
	  context = ConfigurationContextFactory.createConfigurationContextFromFileSystem("repo","repo/conf/axis2_client.xml");

	  // This is the security policy of the proxy service applied UT.
	  StAXOMBuilder builder = new StAXOMBuilder("policy.xml");
	  Policy policy = PolicyEngine.getPolicy(builder.getDocumentElement());

//	  context = ConfigurationContextFactory.createConfigurationContextFromFileSystem("repo","repo/conf/client.axis2.xml");
	  client = new ServiceClient(context, null);
	  options = new Options();
	  options.setAction("urn:echoString");
	  // This is the addressing URL pointing to the echo service deployed in ESB
	  options.setTo(new EndpointReference(ADDR_URL));
	  // To the ESB, the proxy service
	  options.setUserName("admin");
	  options.setPassword("admin");
	  // TRANS_URL points to proxy service
	  options.setProperty(Constants.Configuration.TRANSPORT_URL, TRANS_URL);
	  options.setProperty(RampartMessageData.KEY_RAMPART_POLICY, policy);
	  client.setOptions(options);
	  client.engageModule("addressing");
	  client.engageModule("rampart");
	  response = client.sendReceive(getPayload("Hello world"));
	  System.out.println(response);
	 }
	 
	 private static OMElement getPayload(String value) {
	  OMFactory factory = null;
	  OMNamespace ns = null;
	  OMElement elem = null;
	  OMElement childElem = null;

	  factory = OMAbstractFactory.getOMFactory();
	  ns = factory.createOMNamespace("http://echo.services.core.carbon.wso2.org", "ns1");
	  elem = factory.createOMElement("echoString", ns);
	  childElem = factory.createOMElement("in", null);
	  childElem.setText(value);
	  elem.addChild(childElem);
	  return elem;
	 }
}
