import org.opensaml.xml.security.credential.Credential;
import org.opensaml.xml.security.credential.CredentialContextSet;
import org.opensaml.xml.security.credential.UsageType;
import org.opensaml.xml.security.x509.X509Credential;

import javax.crypto.SecretKey;
import java.security.*;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.Collection;

public class X509CredentialImpl implements X509Credential{

    private KeyStore keyStore = null;
    private String keyStorePass = null;
    private String alias = null;
    private String privateKeyPassword = null;

    public X509CredentialImpl(KeyStore keyStore, String keyStorePass, String alias, String privateKeyPassword){
        this.keyStore = keyStore;
        this.keyStorePass = keyStorePass;
        this.alias = alias;
        this.privateKeyPassword = privateKeyPassword;
    }

    @Override
    public X509Certificate getEntityCertificate() {
        try {
            return (X509Certificate)keyStore.getCertificate(alias);
        } catch (KeyStoreException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public Collection<X509Certificate> getEntityCertificateChain() {
        try {
            Arrays.asList(keyStore.getCertificateChain(alias));
        } catch (KeyStoreException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public PublicKey getPublicKey() {
        try {
            keyStore.getCertificate(alias).getPublicKey();
        } catch (KeyStoreException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public PrivateKey getPrivateKey() {
        try {
            return (PrivateKey)keyStore.getKey(alias, privateKeyPassword.toCharArray());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public SecretKey getSecretKey() {
        try {
            return (SecretKey)keyStore.getKey(alias, keyStorePass.toCharArray());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public Collection<X509CRL> getCRLs() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public String getEntityId() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public UsageType getUsageType() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Collection<String> getKeyNames() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public CredentialContextSet getCredentalContextSet() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Class<? extends Credential> getCredentialType() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
