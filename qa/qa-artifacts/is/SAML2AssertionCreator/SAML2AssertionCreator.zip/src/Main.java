import org.apache.xml.security.c14n.Canonicalizer;
import org.apache.xml.security.signature.XMLSignature;
import org.joda.time.DateTime;
import org.opensaml.Configuration;
import org.opensaml.DefaultBootstrap;
import org.opensaml.common.SAMLVersion;
import org.opensaml.saml1.core.NameIdentifier;
import org.opensaml.saml2.core.*;
import org.opensaml.saml2.core.impl.*;
import org.opensaml.xml.XMLObject;
import org.opensaml.xml.XMLObjectBuilder;
import org.opensaml.xml.io.Marshaller;
import org.opensaml.xml.io.MarshallerFactory;
import org.opensaml.xml.schema.XSString;
import org.opensaml.xml.schema.impl.XSStringBuilder;
import org.opensaml.xml.security.x509.X509Credential;
import org.opensaml.xml.signature.*;
import org.opensaml.xml.util.Base64;
import org.w3c.dom.Element;
import org.w3c.dom.bootstrap.DOMImplementationRegistry;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSOutput;
import org.w3c.dom.ls.LSSerializer;

import javax.xml.namespace.QName;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.net.URLEncoder;
import java.security.KeyStore;
import java.util.*;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;

public class Main {

    private static String username;
    private static String id;
    private static String issuer;
    private static String recipient;
    private static String[] requestedAudiences;
    private static boolean doAssertionSigning;
    private static Map<String, String> claims = new HashMap<String, String>();

    private static String keyStoreFile = null;
    private static String keyStorePassword = null;
    private static String alias = null;
    private static String privateKeyPassword = null;
    
    private static Random random = new Random();
    private static final char[] charMapping = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
            'k', 'l', 'm', 'n', 'o', 'p' };
    private static KeyStore keyStore;

    public static void main(String[] args) throws Exception {

        System.setProperty("java.endorsed.dirs","/devhome/wso2/support/support_sep_2013/TAGDEV-7/src/SAML2AssertionCreator/lib");

        if(args.length < 4){
            throw new Exception("Invalid number of arguments. Atleast 8 arguments required.");
        }

        id = Integer.toHexString(new Double(Math.random()).intValue());
        issuer = args[0];
        username = args[1];
        recipient = args[2];
        requestedAudiences = args[3].split(",");
        keyStoreFile = args[4];
        keyStorePassword = args[5];
        alias = args[6];
        privateKeyPassword = args[7];

        if(args.length > 8){
            String[] claimsArray = args[8].split(",");
            for(String claim:claimsArray){
                String[] keyValue = claim.split(":");
                claims.put(keyValue[0],keyValue[1]);
            }
        }

        doAssertionSigning = true;

        Assertion samlAssertion = buildSAMLAssertion();
        System.out.println("\nAssertion String: " + marshall(samlAssertion) + "\n");
        String assertionString = URLEncoder.encode(Base64.encodeBytes(marshall(samlAssertion).getBytes()),"UTF-8");
        System.out.println("base64-url Encoded Assertion String: " + assertionString + "\n");
    }



    private static Assertion buildSAMLAssertion() throws Exception {

        DefaultBootstrap.bootstrap();
        Assertion samlAssertion = new AssertionBuilder().buildObject();
        try {
            DateTime currentTime = new DateTime();
            DateTime notOnOrAfter = new DateTime(currentTime.getMillis() + 5 * 60 * 1000);
            samlAssertion.setID(createID());
            samlAssertion.setVersion(SAMLVersion.VERSION_20);
            samlAssertion.setIssuer(getIssuer());
            samlAssertion.setIssueInstant(currentTime);
            Subject subject = new SubjectBuilder().buildObject();

            NameID nameId = new NameIDBuilder().buildObject();
            nameId.setValue(username);
            nameId.setFormat(NameIdentifier.EMAIL);

            subject.setNameID(nameId);

            SubjectConfirmation subjectConfirmation =
                    new SubjectConfirmationBuilder().buildObject();
            subjectConfirmation.setMethod("urn:oasis:names:tc:SAML:2.0:cm:bearer");

            SubjectConfirmationData scData = new SubjectConfirmationDataBuilder().buildObject();
            scData.setRecipient(recipient);
            scData.setNotOnOrAfter(notOnOrAfter);
            scData.setInResponseTo(id);
            subjectConfirmation.setSubjectConfirmationData(scData);

            subject.getSubjectConfirmations().add(subjectConfirmation);

            samlAssertion.setSubject(subject);

            AuthnStatement authStmt = new AuthnStatementBuilder().buildObject();
            authStmt.setAuthnInstant(new DateTime());

            AuthnContext authContext = new AuthnContextBuilder().buildObject();
            AuthnContextClassRef authCtxClassRef = new AuthnContextClassRefBuilder().buildObject();
            authCtxClassRef.setAuthnContextClassRef(AuthnContext.PASSWORD_AUTHN_CTX);
            authContext.setAuthnContextClassRef(authCtxClassRef);
            authStmt.setAuthnContext(authContext);
            samlAssertion.getAuthnStatements().add(authStmt);

            if (claims != null) {
                samlAssertion.getAttributeStatements().add(buildAttributeStatement(claims));
            }

            AudienceRestriction audienceRestriction =
                    new AudienceRestrictionBuilder().buildObject();
            if(requestedAudiences != null){
                for(String requestedAudience:requestedAudiences){
                    Audience audience = new AudienceBuilder().buildObject();
                    audience.setAudienceURI(requestedAudience);
                    audienceRestriction.getAudiences().add(audience);
                }
            }
            Conditions conditions = new ConditionsBuilder().buildObject();
            conditions.setNotBefore(currentTime);
            conditions.setNotOnOrAfter(notOnOrAfter);
            conditions.getAudienceRestrictions().add(audienceRestriction);
            samlAssertion.setConditions(conditions);

            if(doAssertionSigning){
                setSignature(samlAssertion, XMLSignature.ALGO_ID_SIGNATURE_RSA, getCredential());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return samlAssertion;
    }

    private static AttributeStatement buildAttributeStatement(Map<String, String> claims) {
        AttributeStatement attStmt = null;
        if (claims != null) {
            attStmt = new AttributeStatementBuilder().buildObject();
            Iterator<String> ite = claims.keySet().iterator();

            for (int i = 0; i < claims.size(); i++) {
                Attribute attrib = new AttributeBuilder().buildObject();
                String claimUri = ite.next();
                attrib.setName(claimUri);
                // look
                // https://wiki.shibboleth.net/confluence/display/OpenSAML/OSTwoUsrManJavaAnyTypes
                XSStringBuilder stringBuilder =
                        (XSStringBuilder) Configuration.getBuilderFactory()
                                .getBuilder(XSString.TYPE_NAME);
                XSString stringValue =
                        stringBuilder.buildObject(AttributeValue.DEFAULT_ELEMENT_NAME,
                                XSString.TYPE_NAME);
                stringValue.setValue(claims.get(claimUri));
                attrib.getAttributeValues().add(stringValue);
                attStmt.getAttributes().add(attrib);
            }
        }
        return attStmt;
    }

    private static String createID() {

        byte[] bytes = new byte[20]; // 160 bits
        random.nextBytes(bytes);

        char[] chars = new char[40];

        for (int i = 0; i < bytes.length; i++) {
            int left = (bytes[i] >> 4) & 0x0f;
            int right = bytes[i] & 0x0f;
            chars[i * 2] = charMapping[left];
            chars[i * 2 + 1] = charMapping[right];
        }

        return String.valueOf(chars);
    }

    public static String marshall(XMLObject xmlObject) throws Exception {

            System.setProperty("javax.xml.parsers.DocumentBuilderFactory",
                    "org.apache.xerces.jaxp.DocumentBuilderFactoryImpl");

            MarshallerFactory marshallerFactory =
                    org.opensaml.xml.Configuration.getMarshallerFactory();
            Marshaller marshaller = marshallerFactory.getMarshaller(xmlObject);
            Element element = marshaller.marshall(xmlObject);

            ByteArrayOutputStream byteArrayOutputStrm = new ByteArrayOutputStream();
            DOMImplementationRegistry registry = DOMImplementationRegistry.newInstance();
            DOMImplementationLS impl = (DOMImplementationLS) registry.getDOMImplementation("LS");
            LSSerializer writer = impl.createLSSerializer();
            LSOutput output = impl.createLSOutput();
            output.setByteStream(byteArrayOutputStrm);
            writer.write(element, output);
            return byteArrayOutputStrm.toString();
    }

    public static String encode(String xmlString) throws Exception {
        Deflater deflater = new Deflater(Deflater.DEFLATED, true);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        DeflaterOutputStream deflaterOutputStream =
                new DeflaterOutputStream(byteArrayOutputStream,
                        deflater);
        deflaterOutputStream.write(xmlString.getBytes());
        deflaterOutputStream.close();
        // Encoding the compressed message
        String encodedRequestMessage =
                Base64.encodeBytes(byteArrayOutputStream.toByteArray(),
                        Base64.DONT_BREAK_LINES);
        return encodedRequestMessage.trim();
    }

    public static Issuer getIssuer() {
        Issuer issuer = new IssuerBuilder().buildObject();
        issuer.setValue(Main.issuer);
        issuer.setFormat("urn:oasis:names:tc:SAML:2.0:nameid-format:entity");
        return issuer;
    }


    public static Assertion setSignature(Assertion assertion, String signatureAlgorithm,
                                         X509Credential cred) throws Exception {

            Signature signature = (Signature) buildXMLObject(Signature.DEFAULT_ELEMENT_NAME);
            signature.setSigningCredential(cred);
            signature.setSignatureAlgorithm(signatureAlgorithm);
            signature.setCanonicalizationAlgorithm(Canonicalizer.ALGO_ID_C14N_EXCL_OMIT_COMMENTS);


                KeyInfo keyInfo = (KeyInfo) buildXMLObject(KeyInfo.DEFAULT_ELEMENT_NAME);
                X509Data data = (X509Data) buildXMLObject(X509Data.DEFAULT_ELEMENT_NAME);
                X509Certificate cert =
                        (X509Certificate) buildXMLObject(X509Certificate.DEFAULT_ELEMENT_NAME);
                String value =
                        org.apache.xml.security.utils.Base64.encode(cred.getEntityCertificate()
                                .getEncoded());
                cert.setValue(value);
                data.getX509Certificates().add(cert);
                keyInfo.getX509Datas().add(data);
                signature.setKeyInfo(keyInfo);

            assertion.setSignature(signature);

            List<Signature> signatureList = new ArrayList<Signature>();
            signatureList.add(signature);

            // Marshall and Sign
            MarshallerFactory marshallerFactory =
                    org.opensaml.xml.Configuration.getMarshallerFactory();
            Marshaller marshaller = marshallerFactory.getMarshaller(assertion);

            marshaller.marshall(assertion);

            org.apache.xml.security.Init.init();
            Signer.signObjects(signatureList);
            return assertion;

    }

    private static XMLObject buildXMLObject(QName objectQName) throws Exception {
        XMLObjectBuilder builder =
                org.opensaml.xml.Configuration.getBuilderFactory()
                        .getBuilder(objectQName);
        if (builder == null) {
            throw new Exception("Unable to retrieve builder for object QName " +
                    objectQName);
        }
        return builder.buildObject(objectQName.getNamespaceURI(), objectQName.getLocalPart(),
                objectQName.getPrefix());
    }

    private static X509Credential getCredential() throws Exception {
        keyStore = KeyStore.getInstance("JKS");
        char[] storePass = keyStorePassword.toCharArray();
        FileInputStream fileInputStream = new FileInputStream(keyStoreFile);
        keyStore.load(fileInputStream, storePass);
        fileInputStream.close();
        return new X509CredentialImpl(keyStore, keyStorePassword, alias, privateKeyPassword);
    }

}
