package org.wso2.rest.security.oauth;

 import java.io.BufferedReader;
 import java.io.IOException;
 import java.io.InputStream;
 import java.io.InputStreamReader;
 import java.net.URL;

 import com.google.gdata.client.GoogleService;
 import com.google.gdata.client.Service.GDataRequest;
 import com.google.gdata.client.authn.oauth.GoogleOAuthParameters;
 import com.google.gdata.client.authn.oauth.OAuthHmacSha1Signer;

public class OauthClient {
    private static final String ESB = "http://127.0.0.1:8280/";

      /**
   * @param args
   */
  public static void main(String[] args) {

   final String CONSUMER_SECRET = "fB5jpJ0PfQiBTKNRiKsYbzm0pjga";
   final String CONSUMER_KEY = "yrPLShTaoDbr7V_VoTGpAxxAXr8a";
   final String OAUTH_TOKEN = "RG2HBo2QrusROa8LcDAo4_Ejdgka";

   GDataRequest request = null;

   try {

    GoogleOAuthParameters oauthParameters = new GoogleOAuthParameters();
    oauthParameters.setOAuthConsumerKey(CONSUMER_KEY);
    oauthParameters.setOAuthConsumerSecret(CONSUMER_SECRET);
    oauthParameters.setOAuthToken(OAUTH_TOKEN);

    OAuthHmacSha1Signer signer = new OAuthHmacSha1Signer();
    GoogleService service = new GoogleService("demoservice", "myapp");
    service.setOAuthCredentials(oauthParameters, signer);
    String param = "hi";
    String baseString = ESB + "services/oauth_proxy/echoString" + "?xoauth_requestor_id="
      + CONSUMER_KEY + "&in=" + param + "&scope=echoService";
    URL feedUrl = new URL(baseString);
    request = service.createFeedRequest(feedUrl);
    request.execute();
    System.out.println(convertStreamToString(request.getResponseStream()));
   } catch (Exception e) {
    e.printStackTrace();
   }
  }

  private static String convertStreamToString(InputStream is) throws IOException {
   if (is != null) {
    StringBuilder sb = new StringBuilder();
    String line;
    try {
     BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
     while ((line = reader.readLine()) != null) {
      sb.append(line).append("\n");
     }
    } finally {
     is.close();
    }
    return sb.toString();
   } else {
    return "";
   }
  } 
}
