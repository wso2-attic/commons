package org.wso2.identity.esb.kerberos;

import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMFactory;
import org.apache.axiom.om.OMNamespace;
import org.apache.axiom.om.impl.builder.StAXOMBuilder;
import org.apache.axis2.AxisFault;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.Options;
import org.apache.axis2.client.ServiceClient;
import org.apache.axis2.context.ConfigurationContext;
import org.apache.axis2.context.ConfigurationContextFactory;
import org.apache.neethi.Policy;
import org.apache.neethi.PolicyEngine;
import org.apache.rampart.RampartMessageData;

public class KerberosClient implements Runnable  {

	/**
	 * @param args
	 */

	final static String RELYING_PARTY_SERVICE_EPR = "https://localhost:9443/services/echo";

    final static String ACTION_REQUEST_DATA = "request";
    final static String ACTION_PUBLISH_DATA = "publish";

    private static ConfigurationContext confContext = null;
	private static Policy servicePolicy = null;

    private int index = 0;

    public KerberosClient(int j) {
        index = j;
    }

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {

		String trustStore = null;
		

		// You need to import the Identity Server, public certificate to this key store.
		// By default it's there - if you use wso2carbon.jks from [ESB_HOME]\resources\security
		trustStore = System.getProperty("user.dir") +"/src/wso2carbon.jks";
		// We are accessing STS over HTTPS - so need to set trustStore parameters.
		System.setProperty("javax.net.ssl.trustStore", trustStore);
		System.setProperty("javax.net.ssl.trustStorePassword", "wso2carbon");

		// Create configuration context - you will have Rampart module engaged in the
		// client.axis2.xml
		confContext = ConfigurationContextFactory.createConfigurationContextFromFileSystem("repo",
				"repo/conf/client.axis2.xml");

		servicePolicy = loadServicePolicy("repo/conf/policy-1.xml");

        ServiceClient client = null;
        try {
            client = new ServiceClient(confContext, null);

            Options options = new Options();

            // Request data

            options.setAction("urn:echoString");


            options.setTo(new EndpointReference(RELYING_PARTY_SERVICE_EPR));
            options.setProperty(RampartMessageData.KEY_RAMPART_POLICY, servicePolicy);

            client.setOptions(options);

            client.engageModule("addressing");
            client.engageModule("rampart");

            String value1 = "Hello World";

            System.out.println("Calling service with parameter 1 - " + value1);

            OMElement response = client.sendReceive(getPayload(value1));
            System.out.println("Response  : " + response);

        } catch (AxisFault axisFault) {
            axisFault.printStackTrace();
            System.out.println("Could not create service client");
        }

	}

    public void x() {
           y();
    }

    public void y() {
        System.out.println("============== getConnection called started. Thread id - " + Thread.currentThread().getId() + " =================");
        StackTraceElement[] elements = Thread.currentThread().getStackTrace();
        for (int i=0; i < elements.length; ++i) {
             System.out.println("\t" + elements[i]);
        }
        System.out.println("============== getConnection called end. Thread id - " + Thread.currentThread().getId() + "=================");

    }

	private static Policy loadServicePolicy(String xmlPath) throws Exception {
		StAXOMBuilder builder = null;
		Policy policy = null;

		builder = new StAXOMBuilder(xmlPath);
		policy = PolicyEngine.getPolicy(builder.getDocumentElement());

		return policy;
	}

	private static OMElement getPayload(String value1) {

        OMFactory factory = OMAbstractFactory.getOMFactory();
        OMNamespace ns = factory.createOMNamespace("http://echo.services.core.carbon.wso2.org","p");
        OMElement elem = factory.createOMElement("echoString", ns);
        OMElement childElem = factory.createOMElement("in", null);
        childElem.setText(value1);
        elem.addChild(childElem);

		return elem;
	}

    public void run() {


        //To change body of implemented methods use File | Settings | File Templates.
    }
}